<?php
/**
 * Inversion de Dependencia:
 * Las clases de alto nivel no pueden depender de clases de bajo nivel y viceversa
 * sino que ambas deben depender de abstracciones
 * 
 * clases o modulos de alto nivel: Son clases donde manejamos la logica de negocio
 * clases o modulos de bajo nivel: Son clases donde manejamos tareas pequeñas pero que la logica de negocio
 * no depende de ellas
 * 
 * abstraccion: clase abstracta o interface
 */

abstract class Documentos{
    abstract public function buscarDocumento($documento);
}

class MySQL extends Documentos{
    public function buscarDocumento($documento){
        return "El documento " . $documento . " esta en la tabla Documents de mysql";
    }
}

class SQLServer extends Documentos{
    public function buscarDocumento($documento){
        return "El documento " . $documento . " esta en la tabla Documents en SQL SERVER";
    }
}

class MongoDB extends Documentos{
    public function buscarDocumento($documento){
        return "El documento " . $documento . " esta en la tabla Documents en Mongo DB";
    }
}

class ProcesarDocumento{
    public function obtenerDocumento(Documentos $doc, $documento){
        return $doc->buscarDocumento($documento);
    }
}

$procesar = new ProcesarDocumento();
echo $procesar->obtenerDocumento(new SQLServer, "principios solid");
echo "\n";
$procesar2 = new ProcesarDocumento();
echo $procesar2->obtenerDocumento(new MongoDB, "algoritmos");


class ProcessDoc{
    public function getDoc(){
        $myqsl = new MySQL();
    }
}

?>