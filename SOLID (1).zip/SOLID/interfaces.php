<?php

interface FormulasFiguras{
    public function calcularRadio();
    public function calcularAreaTriangulo();
    public function obtenerLadosTriangulo();
    public function calcularPerimetro();
}

interface formulaTriangulo{
    public function calcularAreaTriangulo();
    public function obtenerLadosTriangulo();
}

interface formulasCirculo{
    public function calcularRadio();
    public function calcularPerimetro();
}

class Triangulo implements formulaTriangulo{
    //area, lados
    public function calcularAreaTriangulo()
    {
        
    }

    public function obtenerLadosTriangulo(){

    }

}

class Circulo implements formulasCirculo{
    //radio, perimetro
    public function calcularRadio()
    {
        
    }

    public function calcularPerimetro()
    {
        
    }
}




?>