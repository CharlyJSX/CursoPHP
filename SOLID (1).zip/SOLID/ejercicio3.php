<?php
/**
 * Principio que se esta violando: OpenClosed, porque el metodo tipoPago puede cambiar y recibir un nuevo tipo de pago
 * 
 */

class Transferencia{
    public function tipoPago($tipo){
        if($tipo == "tarjetaCredito"){
            //code..
        }
        if($tipo == "payPal"){
            //code..
        }
        if($tipo == "efectivo"){
            //code..
        }
    }
}

//solucion
class Transferencia2{
    public function tipoPago(){
        //code..
    }
}

class TarjetaCredito extends Transferencia2{
    public function tipoPago()
    {
        echo "Estamos con tarjeta de credito";
    }
}

class PayPal extends Transferencia2{
    public function tipoPago()
    {
        echo "Estamos pagando por payPal";
    }
}

class Efectivo extends Transferencia2{
    public function tipoPago()
    {
        echo "Estamos pagando con efectivo";
    }
}

$tarjeta = new TarjetaCredito();
$tarjeta->tipoPago();

$paypal = new PayPal();
$paypal->tipoPago();


#solucion con interfaz
interface TipoPago{
    public function procesarPago();
}

class TarjetaCredito2 implements TipoPago{
    public function procesarPago()
    {
        echo "Estamos con tarjeta de credito";
    }
}

class PayPal2 implements TipoPago{
    public function procesarPago()
    {
        echo "Estamos pagando por payPal";
    }
}

class Efectivo2 implements TipoPago{
    public function procesarPago()
    {
        echo "Estamos pagando con efectivo";
    }
}

class Depositar implements TipoPago{
    public function procesarPago()
    {
        echo "Estoy haciendo un deposito";
    }
}

class Transferencia3{
    public function pagar(TipoPago $tipo){
        echo $tipo->procesarPago();
    }
}

$tranfer = new Transferencia3();
$tranfer->pagar(new Depositar);

?>