<?php

/**
 * clase abstracta: siempre hay un metodo abstracto (metodo donde no definimos comportamiento), ademas puedo
 * tener atributos y metodos con comportamiento
 * 
 * interfaces: Es un contrato donde asignamos metodos abstractos (metodos sin comportamiento)
 */

abstract class Planilla{
    protected $sueldo;
    protected $nombre;
    protected $DUI;

    abstract function calcularDeducciones();

    public function obtenerSeguro($seguro){
        //code..
    }
}

interface PayRoll{
    public function calculateDeductions();
}

interface Bonos{
    public function getBonos();
}

class Employee implements PayRoll, Bonos{
    public $nombre;
    public $apellido; 
    
    public function calculateDeductions(){
        //code..
    }

    public function getBonos()
    {
        
    }
}

class Cliente extends Planilla{

    public function calcularDeducciones()
    {
        //code..
    }

    public function infoCliente(){
        $this->nombre = "julano";
    }

}

$cliente = new Cliente();
$cliente->obtenerSeguro("Fghjkl");


?>