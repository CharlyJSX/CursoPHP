<?php
/**
 * Open Closed: Las clases pueden extender, pero estan cerradas a modificacion
 */

interface TipoArchivo{
    public function tipoArchivo();
}

abstract class File{
    abstract function getFile();

    public function documento(){
        return "Estas procesando un documento";
    }
}

class Gif implements TipoArchivo{

    public function tipoArchivo()
    {
        return "Gif";
    }
}

class Mp4 implements TipoArchivo{
    public function tipoArchivo()
    {
        return "Mp4";
    }
}

class Mp3 implements TipoArchivo{
    public function tipoArchivo()
    {
        return "Mp3";
    }
}

class Png implements TipoArchivo{
    public function tipoArchivo()
    {
        return "Png";
    }
}

class Archivos{

    public function obtenerArchivo($archivo){
        switch($archivo){
            case "mp3":
                //code..
                break;
            case "mp4":
                //code..
                break;
            case "gif":
                //code..
                break;
            
            default:
                return "Selecciona un tipo de archivo correcto";

        }
    }


    public function procesarArchivo(){

    }
}




?>