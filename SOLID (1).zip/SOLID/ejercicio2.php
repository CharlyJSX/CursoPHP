<?php
/**
 * principio que se esta violando: LISKOV, porque la clase hija no puede reemplazar el metodo de la clase padre
 * arroja una excepcion
 * 
 */
class Adulto {
    public function pago(){
        echo "Es mayor de edad puede pagar";
    }
}

class Niño extends Adulto{
    public function pago()
    {
        throw new Exception("el niño no puede pagar");
    }
}

/** solucion */
interface Pay{
    public function typePay();
}

class Adult implements Pay{
    public function typePay()
    {
        echo "Un adulto si puede pagar";
    }
}

class Children{
    public function hobbies(){
        //code..
    }
}


?>