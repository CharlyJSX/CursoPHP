<?php


/**
 * LISKOV: Clases hijas pueden facilmente reemplazar una clase padre
 */

class Animal2{

    public function volar(){

    }

    public function nadar(){

    }

    public function caminar(){

    }
}

class Gato extends Animal2{

    public function volar(){
        //return throw new Error("El gato no vuela");
    }
}

class Aguila extends Animal2{
    public function nadar()
    {
        //return throw new Error("El aguila no nada");
    }

    public function caminar(){
        //return throw new Error("El aguila no puede caminar");
    }
}


interface animalVolador{
    public function volar();
}

interface animalNadar{
    public function nadar();
}

interface animalCaminar{
    public function caminar();
}

class Gato1 implements animalNadar, animalCaminar{
    public function nadar(){
        //code..
    }

    public function caminar(){
        //code..
    }
}

class Aguila1 implements animalVolador{
    public function volar(){
        //code..
    }
}


?>