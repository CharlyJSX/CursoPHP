<?php
/**
 * principio se esta violando: Single Responsability
 */
class Employee{
    public function saveEmployee(){
        //code..
    }
    public function connection(){
        //code..
    }
    
}

/** solucion */
class Employee2 extends ConnectionDB{
    public function register(){
        //code..
        $this->connection();
        //insert into empleados ....
    }

    public function update(){

    }

    public function delete(){

    }
}

class ConnectionDB{
    public function connection(){
        //code..
    }
}

class Report extends ConnectionDB{
    public function getEmployees(){
        //code..
        $this->connection();
        //select * from empleados
    }

    public function getEmployeeByDepartment(){
        //code..
    }
}




?>