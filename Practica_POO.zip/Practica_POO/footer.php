<footer>
    <h1>Hecho por kenia</h1>
</footer>