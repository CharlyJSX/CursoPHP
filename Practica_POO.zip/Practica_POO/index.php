<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Descuento Turista</title>
</head>
<style>
    h1{
        color: red;
    }
</style>
<body>
    <?php require "ejercicio.php"; ?>
    <h1>Descuentos Turisticos</h1>
    <form action="" method="POST">
        <label for="">Nombre Completo</label>
        <input type="text" name="nombre"  placeholder="Ingresa tu nombre"><br>
        <label for="">Direccion</label>
        <input type="text" name="direccion" placeholder="Ingresa tu direccion"><br>
        <label for="">Seleccione Origen</label>
        <select name="origen" id="">
            <option value="La Palma">La Palma</option>
            <option value="San Ignacio">San Ignacio</option>
            <option value="San Salvador">San Salvador</option>
        </select><br>
        <label for="">Seleccione Destino</label>
        <select name="destino" id="">
            <option value="costa del sol">Costa del Sol</option>
            <option value="panchimalco">Panchimalco</option>
            <option value="puerto del triunfo">Puerto del Triunfo</option>
        </select><br>
        <label for="">Cantidad</label>
        <input type="text" name="cantidad" placeholder="Ingresa la cantidad del viaje"><br>
        <input type="submit" name="" value="Enviar Datos">
    </form>
    <?php
        if(isset($_POST['nombre'],$_POST['direccion'],$_POST['origen'],$_POST['destino'],$_POST['cantidad'])){
            $descuento = new Descuento($_POST['nombre']);
            $descuento->setDireccion($_POST['direccion']);
            $descuento->setOrigen($_POST['origen']);
            $descuento->setDestino($_POST['destino']);
            $descuento->setDinero($_POST['cantidad']);
            echo $descuento->getDireccion();
            echo "<br>";
            echo $descuento->getOrigen();
            echo "<br>";
            echo $descuento->getDestino();
            echo "<br>";
            echo $descuento->getDinero();
            echo "<br>";
            $descuento->calcularDescuento();
        }
    ?>

    <?php include "footer.php" ?>
</body>
</html>