<?php
/**
 * Crear  una Funciónpara  calcular  el  descuento  en  viajes  turísticos  tomando  en  cuenta  lo siguiente: Si el usuario introduce como origen la ciudad de Palma y como destino La costa del Sol, el descuento será de 5%, si el destino es Panchimalco el descuento será del 10% y si el destino es Puerto el Triunfo el descuento será del 15%.
 * 
 * clase, datos de la persona, dinero, descuento
 * formulario: select origen y destino
 * 
 */

class Descuento{
    /** asignacion los atributos */
    public $nombre;
    private $direccion;
    private $origen;
    private $destino;
    private $dinero;

    /** metodos */
    public function __construct($nombre)
    {
        $this->nombre = $nombre;
    }

    /** utilizando set y get */
    public function setDireccion($dire){
        $this->direccion = $dire;
    }

    public function getDireccion(){
        return "<b>Direccion:</b> $this->direccion";
    }

    public function setOrigen($origen){
        $this->origen = $origen;
    }

    public function getOrigen(){
        return "<b>Ciudad de Origen:</b> $this->origen";
    }

    public function setDestino($destino){
        $this->destino = $destino;
    }

    public function getDestino(){
        return "<b>Lugar de Destino:</b> $this->destino";
    }

    public function setDinero($dinero){
        $this->dinero = $dinero;
    }

    public function getDinero(){
        return "<b>Pago del viaje:</b> $this->dinero";
    }

    /** metodo para obtener descuento */
    public function calcularDescuento(){
        if($this->origen == "La Palma" && $this->destino == "costa del sol" ){
            $this->dinero = $this->dinero - $this->dinero * 0.05;
            echo "<b>Pago total del viaje:</b> $this->dinero, tienes el descuento del 5%";
        }else if($this->origen == "La Palma" && $this->destino == "panchimalco"){
            $this->dinero = $this->dinero - $this->dinero * 0.10;
            echo "<b>Pago total del viaje:</b> $this->dinero, tienes el descuento del 10%";
        }else if($this->origen == "La Palma" && $this->destino == "puerto del triunfo"){
            $this->dinero = $this->dinero - $this->dinero * 0.15;
            echo "<b>Pago total del viaje:</b> $this->dinero, tienes el descuento del 15%";
        }else{
            echo "<b>Tu destino no tiene descuento</b>";
        }
    }

}

?>