<?php

/**
 * Segregacion de interfaces: Divide y venceras
 * Es mejor tener varias interfaces a tener solo una
 * 
 * Interface: Es un contrato obligatorio para las clases que lo implementan
 */

interface Invalida{
    public function proyectManager();
    public function testear();
    public function codificar();
    public function diseñar();
}

interface Scrum{
    public function proyectManager();
}

interface DeveloperUI{
    public function diseñoUI();
}

interface DeveloperBD{
    public function analisisDatos();
}

interface DeveloperFront{
    public function maquetacion();
}

interface DeveloperTester{
    public function testing();
}

class ScrumManager implements Scrum{
    public function proyectManager()
    {
        return "Estoy en reunion";
    }
}


?>