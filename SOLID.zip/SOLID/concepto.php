<?php

/**
 * Principios SOLID
 * Son reglas para mantener nuestro codigo limpio, buenas practicas y reforzar los pilares de POO
 * 
 * 5 principios: single responsability, open closed, LISKOV Substitution, Interface Segregation, 
 *  Dependency Inversion
 */


?>