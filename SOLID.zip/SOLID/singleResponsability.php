<?php
/**
 * Responsabilidad Unica: Una clase solo debe tener una unica responsabilidad o una unica forma de cambiar
 */

class Reporte{
    public function obtenerEstudiantes(){

    }

    public function obtenerMaestros(){
        
    }


}

class Login{
    public function iniciarSesion(){

    }

    public function obtenerRoles(){

    }
}

class ConexionDB{
    public function conectar(){

    }
}

class Estudiante{

    public function registrar(){

    }

    public function actualizar(){

    }
}



?>