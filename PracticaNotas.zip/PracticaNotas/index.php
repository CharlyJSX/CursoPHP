<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <?php include "recursos/header.php"; 
        require "ejercicio.php";
    ?>


    <div class="container">
        <form action="" method="POST">
            <label for="">Nombre Completo:</label>
            <input type="text" class="form-control" name="nombre" placeholder="Ingresa tu nombre completo">
            <label for="">Nota del Examen</label>
            <input type="text" class="form-control" name="examen" placeholder="Ingresa tu nota de examen">
            <label for="">Nota de Asistencia</label>
            <input type="text" class="form-control" name="asistencia" placeholder="Ingresa tu asistencia">
            <label for="">Nota de Tareas:</label>
            <input type="text" class="form-control" name="tareas" placeholder="Ingresa tu nota de tareas">
            <label for="">Nota de Investigacion:</label>
            <input type="text" class="form-control" name="investigacion" placeholder="Ingresa tu nota de investigacion">

            <input type="submit" value="Guardar Datos" class="btn btn-success">
        </form>
        
        <?php
            if(isset($_POST['nombre'], $_POST['examen'], $_POST['asistencia'], $_POST['tareas'], $_POST['investigacion'])){

                /** instanciando la clase */
                $alumno = new Alumno($_POST['nombre']);
                $alumno->setTarea($_POST['tareas']);
                $alumno->setExamen($_POST['examen']);
                $alumno->setAsistencia($_POST['asistencia']);
                $alumno->setInvestigacion($_POST['investigacion']);
            }

        ?>
        <table class="table table-hover">
            <thead>
                <th>Nombre</th>
                <th>Nota</th>
            </thead>
            <tbody>
                <?php echo $alumno->calcularNota(); ?>
            </tbody>
        </table>
    </div>

    <?php include "recursos/footer.php"; ?>
</body>
</html>