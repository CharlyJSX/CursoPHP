<?php
/**
 * Crear una función que determine la nota final de un alumno, la cual depende de lo siguiente: 
* Examen =20%
* tareas = 40%
* asistencia = 10%
* investigación = 30%
 */

class Alumno{
    //nombre, examen, tarea, asistencia, investigacion
    public $nombre;
    private $asistencia;
    private $examen;
    private $tarea;
    private $investigacion;

    public function __construct($nombre)
    {
        $this->nombre = $nombre;
    }

    /** metodos set y get */
    public function setAsistencia($asistencia){
        $this->asistencia = $asistencia * 0.10;
    }

    public function getAsistencia(){
        return $this->asistencia;
    }

    public function setExamen($examen){
        $this->examen = $examen * 0.20;
    }

    public function getExamen(){
        return $this->examen;
    }

    public function setTarea($tarea){
        $this->tarea = $tarea * 0.40;
    }

    public function getTarea(){
        return $this->tarea;
    }

    public function setInvestigacion($investigacion){
        $this->investigacion = $investigacion * 0.30;
    }

    public function getInvestigacion(){
        return $this->investigacion;
    }

    public function calcularNota(){
        $notafinal = $this->tarea + $this->examen + $this->asistencia + $this->investigacion;
        //return "$this->nombre, tu nota global es " . $notafinal;
        $tabla = "";
        $tabla .= "<tr><td>$this->nombre</td> <td>$notafinal</td></tr>";
        echo $tabla;
    }

}

/**
 * argumento: es el valor del parametro
 * parametro: es la variable que asignamos en la funcion
 * atributo: es la caracteristica del objeto, lo que representa una propiedad de la clase
 */

?>