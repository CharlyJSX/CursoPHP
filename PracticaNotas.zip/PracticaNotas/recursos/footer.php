<footer class="bg-dark">
    <h1 class="text-center fst-italic text-white">2023</h1>
</footer>