<header class="bg-primary">
    <h1 class="text-center fst-italic text-white">Notas Estudiantiles</h1>
</header>